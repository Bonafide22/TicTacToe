#include <iostream>
#include <vector>
#include <string>
#include <fstream>

#define UNDERLINE "\033[4m"
#define CLOSEUNDERLINE "\033[0m"

using namespace std;

void print_menu(){
   cout << " ********************************* " << endl;
   cout << " ****Tic****Tac****Toe****Game**** " << endl;
   cout << " Please select your option: " << endl;
   cout << " N: New game " << endl;
   cout << " C: Continue game " << endl;
   cout << " S: Save score " << endl;
   cout << " V: View highscores " << endl;
   cout << " Q: Quit" << endl;
   cout << " ********************************* " << endl;
}
struct PlayerSelect {
    string p1Name;
    string p2Name;
    string p1Sign;  
    string p2Sign;
    int p1Wins = 0;
    int p2Wins = 0;
};

void PlayGame (PlayerSelect& pSelection) {       //function housing the actual game
    vector<string> gridNum = {"1","2","3","4","5","6","7","8","9"};
    int varIn; 
    int playerTurn = 1;
    
    cout << UNDERLINE << " " << gridNum.at(0) << " | " << gridNum.at(1) << " | " << gridNum.at(2) << " " << CLOSEUNDERLINE << endl;
    cout << UNDERLINE << " " << gridNum.at(3) << " | " << gridNum.at(4) << " | " << gridNum.at(5) << " " << CLOSEUNDERLINE << endl;
    cout << " " << gridNum.at(6) << " | " << gridNum.at(7) << " | " << gridNum.at(8) << " " << endl << endl;
       
    do{     //Start of the loop for the game
        cout << "Enter the available number from the grid where you want to place your piece, enter 10 to quit." << endl;
        cin >> varIn;
        
        if(varIn == 10) break;                                   //Check for quit operator
        while (varIn < 1 || varIn > 10) {                        //Check for out of bounds number
            cout << "Wrong number entered!" << endl;
            cin >> varIn;
        }
        
            if (playerTurn == 1) {
                if( ((gridNum.at((varIn - 1))) == "X") || (gridNum.at((varIn - 1)) == "O") ) {         //Checking for overwrites
                    cout << "Number already occupied! NO CHEATING!" << endl;
                    continue;  }
                
                else gridNum.at(varIn - 1) = pSelection.p1Sign;      
                   }
            else {
                if( ((gridNum.at((varIn - 1))) == "X") || (gridNum.at((varIn - 1)) == "O") ) {         //Checking for overwrites
                    cout << "Number already occupied! NO CHEATING!" << endl;
                    continue;  }
                else gridNum.at(varIn - 1) = pSelection.p2Sign;
                 }

            cout << UNDERLINE << " " << gridNum.at(0) << " | " << gridNum.at(1) << " | " << gridNum.at(2) << " " << CLOSEUNDERLINE << endl;
            cout << UNDERLINE << " " << gridNum.at(3) << " | " << gridNum.at(4) << " | " << gridNum.at(5) << " " << CLOSEUNDERLINE << endl;
            cout << " " << gridNum.at(6) << " | " << gridNum.at(7) << " | " << gridNum.at(8) << " " << endl; 
            
            if (playerTurn == 1) playerTurn = 2;    //Swapping between player 1 and player 2
            else playerTurn = 1;
            
            // CHECKS IF PLAYER1 WINS HORIZONTAL
            if (gridNum.at(0) == pSelection.p1Sign && gridNum.at(1) == pSelection.p1Sign && gridNum.at(2) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p1Name << endl;
                pSelection.p1Wins = pSelection.p1Wins + 1;
                break;
            }
            if (gridNum.at(3) == pSelection.p1Sign && gridNum.at(4) == pSelection.p1Sign && gridNum.at(5) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p1Name << endl;
                pSelection.p1Wins = pSelection.p1Wins + 1;                break;
            }
            if (gridNum.at(6) == pSelection.p1Sign && gridNum.at(7) == pSelection.p1Sign && gridNum.at(8) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p1Name << endl;
                pSelection.p1Wins = pSelection.p1Wins + 1;
                break;
            }
            
            // CHECKS IF PLAYER1 WINS DIAGONAL
            if (gridNum.at(0) == pSelection.p1Sign && gridNum.at(4) == pSelection.p1Sign && gridNum.at(8) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p1Name << endl;
                pSelection.p1Wins = pSelection.p1Wins + 1;
                break;
            }
            if (gridNum.at(2) == pSelection.p1Sign && gridNum.at(4) == pSelection.p1Sign && gridNum.at(6) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p1Name << endl;
                pSelection.p1Wins = pSelection.p1Wins + 1;
                break;
            }
            
            // CHECKS IF PLAYER1 WINS VERTICAL
            if (gridNum.at(0) == pSelection.p1Sign && gridNum.at(3) == pSelection.p1Sign && gridNum.at(6) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p1Name << endl;
                pSelection.p1Wins = pSelection.p1Wins + 1;
                break;
            }
            if (gridNum.at(1) == pSelection.p1Sign && gridNum.at(4) == pSelection.p1Sign && gridNum.at(7) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p1Name << endl;
                pSelection.p1Wins = pSelection.p1Wins + 1;
                break;
            }
            if (gridNum.at(2) == pSelection.p1Sign && gridNum.at(5) == pSelection.p1Sign && gridNum.at(8) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p1Name << endl;
                pSelection.p1Wins = pSelection.p1Wins + 1;
                break;
            }
            
            // CHECKS IF PLAYER2 WINS HORIZONTAL
            if (gridNum.at(0) == pSelection.p2Sign && gridNum.at(1) == pSelection.p1Sign && gridNum.at(2) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p2Name << endl;
                pSelection.p2Wins = pSelection.p2Wins + 1;
                break;
            }
            if (gridNum.at(3) == pSelection.p2Sign && gridNum.at(4) == pSelection.p1Sign && gridNum.at(5) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p2Name << endl;
                pSelection.p2Wins = pSelection.p2Wins + 1;
                break;
            }
            if (gridNum.at(6) == pSelection.p2Sign && gridNum.at(7) == pSelection.p1Sign && gridNum.at(8) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p2Name << endl;
                pSelection.p2Wins = pSelection.p2Wins + 1;
                break;
            }
            
            // CHECKS IF PLAYER2 WINS DIAGONAL
            if (gridNum.at(0) == pSelection.p2Sign && gridNum.at(4) == pSelection.p1Sign && gridNum.at(8) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p2Name << endl;
                pSelection.p2Wins = pSelection.p2Wins + 1;
                break;
            }
            if (gridNum.at(2) == pSelection.p2Sign && gridNum.at(4) == pSelection.p1Sign && gridNum.at(6) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p2Name << endl;
                pSelection.p2Wins = pSelection.p2Wins + 1;
                break;
            }
            
            // CHECKS IF PLAYER2 WINS VERTICAL
            if (gridNum.at(0) == pSelection.p2Sign && gridNum.at(3) == pSelection.p1Sign && gridNum.at(6) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p2Name << endl;
                pSelection.p2Wins = pSelection.p2Wins + 1;
                break;
            }
            if (gridNum.at(1) == pSelection.p2Sign && gridNum.at(4) == pSelection.p1Sign && gridNum.at(7) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p2Name << endl;
                pSelection.p2Wins = pSelection.p2Wins + 1;
                break;
            }
            if (gridNum.at(2) == pSelection.p2Sign && gridNum.at(5) == pSelection.p1Sign && gridNum.at(8) == pSelection.p1Sign) {
                cout << "The winner is " << pSelection.p2Name << endl;
                pSelection.p2Wins = pSelection.p2Wins + 1;
                break;
            }
            
    } while (varIn != 10);
}

void PlayerInfoInput(PlayerSelect& pSelection) {
    cout << "Enter player 1 name:" << endl;
    cin >> pSelection.p1Name;
    cout << "Enter player 1 sign('X' or 'O' only)" << endl;
    cin >> pSelection.p1Sign;
    cout << "Enter player 2 name:" << endl;
    cin >> pSelection.p2Name;
    cout << "Enter player 2 sign('X' or 'O' only)" << endl;
    cin >> pSelection.p2Sign;
}

int main() {
    PlayerSelect pSelection;
    fstream myfile;
    char user_input;

  do{
    print_menu();
    cin >> user_input;
    cout << endl;

    switch(user_input) {
      case 'N': // New game
        PlayerInfoInput(pSelection);
        PlayGame (pSelection);
        break;

      case 'C': // Continue game
        PlayGame (pSelection);
        break;
        
      case 'S': // Save score
        myfile.open ("scores.txt");
        myfile << pSelection.p1Name;
        myfile << pSelection.p1Wins;
        myfile << pSelection.p2Name;
        myfile << pSelection.p2Wins;
        myfile.close();
        cout << "Score Saved";
        break;
        
      case 'V': // View highscores
        cout << "Player 1 Score:" << pSelection.p1Wins << endl << "Player 2 Score:" << pSelection.p2Wins << endl;
        break;
        
      case 'Q': //quit game
        return 1;
        break;

      default:
        cout << "Invalid input" << endl;
        break;
    }
  } while(user_input != 'Q');
  
    PlayerInfoInput(pSelection);
    
    PlayGame(pSelection);   
    
    
    
    
    return 0;
}






